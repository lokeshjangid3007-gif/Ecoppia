# Ecoppia

A starter Android app built with Kotlin and Jetpack Compose.

- Package: `com.ecoppia.app`
- Min SDK 24, target SDK 34

## Run it

1. Install Android Studio (Koala or newer).
2. Choose **File > Open** and select this `Ecoppia` folder.
3. Wait for Gradle sync to finish (it downloads the wrapper and dependencies).
4. Pick an emulator or a connected phone and press **Run**.

## Build an APK from the command line

After the first sync in Android Studio has created the Gradle wrapper:

```
./gradlew assembleDebug
```

The APK is written to `app/build/outputs/apk/debug/`.
